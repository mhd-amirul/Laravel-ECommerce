<!-- Google Font -->
<link rel="stylesheet" href="{{ url('css/googleapis.fonts.css') }}" type="text/css" />
{{-- <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet"/> --}}

<!-- Css Styles -->
<link rel="stylesheet" href="{{ url('css/bootstrap.min.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('css/font-awesome.min.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('css/themify-icons.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('css/elegant-icons.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('css/owl.carousel.min.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('css/nice-select.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('css/jquery-ui.min.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('css/slicknav.min.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('css/style.css') }}" type="text/css" />