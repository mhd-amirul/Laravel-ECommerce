<?php

namespace App\Repository\Interfaces;

interface ContactRepositoryInterface {
    public function Contact();
}