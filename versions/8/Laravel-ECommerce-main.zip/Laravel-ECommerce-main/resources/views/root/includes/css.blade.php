<!-- Google Font -->
<link rel="stylesheet" href="{{ url('Assets/css/googleapis.fonts.css') }}" type="text/css" />
{{-- <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet"/> --}}

<!-- Css Styles -->
<link rel="stylesheet" href="{{ url('Assets/css/bootstrap.min.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('Assets/css/font-awesome.min.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('Assets/css/themify-icons.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('Assets/css/elegant-icons.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('Assets/css/owl.carousel.min.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('Assets/css/nice-select.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('Assets/css/jquery-ui.min.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('Assets/css/slicknav.min.css') }}" type="text/css" />
<link rel="stylesheet" href="{{ url('Assets/css/style.css') }}" type="text/css" />