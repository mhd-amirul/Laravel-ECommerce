<?php

namespace App\Services\Interfaces;

interface GeneralServiceInterface {
    public function basicItem();
    public function sendMessage(array $item);
}